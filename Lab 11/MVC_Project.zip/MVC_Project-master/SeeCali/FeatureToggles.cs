﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SeeCali
{
    public class FeatureToggles
    {
        public bool DeveloperExceptions { get; set; }
    }
}
