﻿namespace SeeCali.Models
{
    public class MonthlySpecial28
    {
        public string Key { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public int Price { get; set; }
    }
}
